import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Conta conta = new Conta();
        conta.setSaldoAtual(100);

        System.out.println("Bem vindo a Nú-banco");
        System.out.println("\nDigite seu nome:");
        conta.setNome(scanner.nextLine());

        System.out.println("\nSeja bem-vindo " + conta.getNome() + "!");
        System.out.println("Você tem: R$" + conta.getSaldoAtual() + " na sua conta!");

        int opcao;
        int i = 0;
        int valor;
        int dinheiro;
        int porcentual = 15 / 100;

        do {
            System.out.println("\n\n Escolha a opção desejada");
            System.out.println("1 - Sacar");
            System.out.println("2 - Depositar");
            System.out.println("3 - Investir");
            System.out.println("3 - Ver saldo das carteiras");
            System.out.print("Opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {

                case 1: {
                    conta.sacar();
                    break;
                }

                case 2: {
                    conta.depositar();
                    break;
                }
                case 3: {
                    conta.investir();
                    break;
                }

                case 4: {
                    conta.versaldo();
                    break;
                }
            }

            conta.setSaldoInvestido(conta.getSaldoInvestido() + (conta.getSaldoInvestido() * 15/100));
            System.out.println("O valor da sua conta de investidor rendeu 5%");
            System.out.println("Seu saldo da conta de investidor atual é de:" + conta.getSaldoInvestido());
        }while (i != 4) ;
    }
}


