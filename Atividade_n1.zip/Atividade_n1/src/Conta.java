import java.math.BigDecimal;
import java.util.Scanner;

public class Conta {
    private String nome;
    private float saldoAtual;
    private float saldoInvestido;

    public void versaldo()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Seu saldo atual da carteira é de: R%"+ getSaldoAtual());
        System.out.println("Seu saldo atual da carteira de investimentos é de: R%"+ getSaldoInvestido());

    }
    public void sacar(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Quanto você deseja sacar:");
        float resgatarDinheiro = scanner.nextFloat();
        float total = saldoAtual - resgatarDinheiro;
        System.out.println("O seu saldo atual é de: R$" + total);
        total = getSaldoAtual();

    }

    public void depositar(){
        Scanner scanner =  new Scanner(System.in);

        System.out.println("Quanto você deseja depositar:");
        float depositarDinheiro = scanner.nextFloat();
        float total = saldoAtual + depositarDinheiro;
        System.out.println("O seu saldo atual é de: R$" + total);
        setSaldoAtual(total);

    }

    public void investir(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Quanto você deseja investir:");
        float investirDinheiro = scanner.nextFloat();
        float total = saldoInvestido + investirDinheiro;
        System.out.println("O seu saldo da sua carteira de investimentos atualmente é de: R$" + total);
        setSaldoAtual(getSaldoAtual()-getSaldoInvestido());
        System.out.println("Saldo da sua carteira do banco atualmente é de: R$" + getSaldoAtual());
        setSaldoInvestido(total);

    }
    public String getNome() {
        return nome;
    }

    public float getSaldoAtual() {
        return saldoAtual;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSaldoAtual(float saldoAtual){
        this.saldoAtual = saldoAtual;
    }

    public float getSaldoInvestido() {
        return saldoInvestido;
    }

    public void setSaldoInvestido(float saldoInvestido) {
        this.saldoInvestido = saldoInvestido;
    }
}
